import React from "react";

function AddRoom() {
  return <div>AddRoom</div>;
}

export default AddRoom;
