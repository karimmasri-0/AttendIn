import React from 'react'

function AddStudent() {
  return (
    <div>AddStudent</div>
  )
}

export default AddStudent