import React from "react";

function TeacherNavBar() {
  return <div>TeacherNavBar</div>;
}

export default TeacherNavBar;
