import React from 'react'

export const Teacher = () => {
  return (
    <div>
        <h1>Teacher Page</h1>
        </div>
  )
}
