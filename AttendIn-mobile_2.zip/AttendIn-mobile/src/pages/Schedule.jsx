import React from 'react'

export const Schedule = () => {
  return (
    <div>
     <h1> Schedule page</h1>
      </div>
  )
}
