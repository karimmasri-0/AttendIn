import React from 'react'

export const Room = () => {
  return (
    <div>
        <h1>Room Page</h1></div>
  )
}
