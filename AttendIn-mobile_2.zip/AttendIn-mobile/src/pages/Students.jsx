import React from 'react';

const About = () => {
    return (
        <div>
            <h1>Students page</h1>
        </div>
    );
};

export default About;