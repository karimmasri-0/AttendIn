import React from 'react'

export const Attendance = () => {
  return (
    <div>
        <h1>
            Attendance Room
        </h1>
        </div>
  )
}
